import React from 'react'
import FrameComp from '../components/FrameComp';

export default function frame() {
    return (
        <div>
            <FrameComp/>
        </div>
    )
}
