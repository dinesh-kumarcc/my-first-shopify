import React from 'react'
import AutocompleteExample from '../components/AutoComplete';

export default function Home() {
    return (
        <div>
            <AutocompleteExample/>
        </div>
    )
}
